#include "frames.hpp"

#include <algorithm>
#include <limits>

#include "draw.hpp"
#include "math.hpp"

using namespace anm2ed::util;

namespace anm2ed::model
{
  void frame_mix(Frame& frame, const Frame& next, float amount)
  {
    frame.rotation = glm::mix(frame.rotation, next.rotation, amount);
    frame.position = glm::mix(frame.position, next.position, amount);
    frame.scale = glm::mix(frame.scale, next.scale, amount);
    frame.shear = glm::mix(frame.shear, next.shear, amount);
    frame.colorOffset = glm::mix(frame.colorOffset, next.colorOffset, amount);
    frame.tint = glm::mix(frame.tint, next.tint, amount);
  }

  // Splits an interpolated frame into uninterpolated frames of at most `interval`; the first keeps the frame's uid.
  std::vector<Frame> frame_bake_split(const Frame& original, const Frame& next, int interval, bool isRoundScale,
                                      bool isRoundRotation)
  {
    auto total = std::max(original.duration, FRAME_DURATION_MIN);
    interval = std::max(interval, FRAME_DURATION_MIN);
    std::vector<Frame> frames{};
    for (int duration = 0; duration < total; duration += interval)
    {
      auto& baked = frames.emplace_back(duration == 0 ? original : frame_clone(original));
      frame_mix(baked, next, interpolation_factor(original.interpolation, (float)duration / total));
      baked.duration = std::min(interval, total - duration);
      baked.interpolation = Interpolation::NONE;
      if (isRoundScale) baked.scale = glm::round(baked.scale);
      if (isRoundRotation) baked.rotation = std::round(baked.rotation);
    }
    return frames;
  }

  glm::mat4 frame_parent_model_get(const Frame& frame)
  {
    return math::quad_model_parent_get(frame.position, {}, math::percent_to_unit(frame.scale), frame.rotation,
                                       math::percent_to_unit(frame.shear));
  }

  void frame_root_transform_apply(Frame& frame, const Frame& rootFrame, bool isRoundScale, bool isRoundRotation,
                                  bool isUseRootPivot)
  {
    auto rootScale = math::percent_to_unit(rootFrame.scale);
    auto pivot = isUseRootPivot ? rootFrame.position : glm::vec2();
    auto offset = (frame.position - pivot) * rootScale;
    auto radians = glm::radians(rootFrame.rotation);
    auto cos = std::cos(radians);
    auto sin = std::sin(radians);

    frame.position = rootFrame.position + glm::vec2(offset.x * cos - offset.y * sin, offset.x * sin + offset.y * cos);
    frame.scale *= rootScale;
    frame.rotation += rootFrame.rotation;
    frame.tint *= rootFrame.tint;
    frame.colorOffset += rootFrame.colorOffset;

    if (isRoundScale) frame.scale = glm::round(frame.scale);
    if (isRoundRotation) frame.rotation = std::round(frame.rotation);
  }

  // The track's state at a time: the frame playing then, mixed toward the next one when interpolated. A trigger is
  // returned only on its exact frame; otherwise the result is invisible.
  Frame frame_generate(const Track& track, float time)
  {
    Frame frame{};
    frame.isVisible = false;
    if (track.frames.empty()) return frame;
    time = std::max(time, 0.0f);

    if (track.type == ItemType::TRIGGER)
    {
      for (const auto& trigger : track.frames)
        if ((int)time == trigger.atFrame) return trigger;
      return frame;
    }

    const Frame* next{};
    int durationCurrent{};
    int durationNext{};
    for (int i = 0; i < (int)track.frames.size(); ++i)
    {
      frame = track.frames[i];
      durationNext += frame.duration;
      if (time >= durationCurrent && time < durationNext)
      {
        if (i + 1 < (int)track.frames.size()) next = &track.frames[i + 1];
        break;
      }
      durationCurrent += frame.duration;
    }

    if (frame.interpolation != Interpolation::NONE && next && frame.duration > 1)
      frame_mix(frame, *next,
                interpolation_factor(frame.interpolation, (time - durationCurrent) / (durationNext - durationCurrent)));
    return frame;
  }

  int frame_index_from_at_frame_get(const Track& track, int atFrame)
  {
    for (int i = 0; i < (int)track.frames.size(); ++i)
      if (track.frames[i].atFrame == atFrame) return i;
    return -1;
  }

  int frame_index_from_time_get(const Track& track, float time)
  {
    if (track.type == ItemType::TRIGGER) return frame_index_from_at_frame_get(track, (int)time);
    if (track.frames.empty()) return -1;
    if (time <= 0.0f) return 0;

    float duration{};
    for (int i = 0; i < (int)track.frames.size(); ++i)
    {
      duration += track.frames[i].duration;
      if (time < duration) return i;
    }
    return (int)track.frames.size() - 1;
  }

  float frame_time_from_index_get(const Track& track, int index)
  {
    if (index < 0 || index >= (int)track.frames.size()) return 0.0f;
    if (track.type == ItemType::TRIGGER) return (float)track.frames[index].atFrame;
    float time{};
    for (int i = 0; i < index; ++i)
      time += track.frames[i].duration;
    return time;
  }

  void frame_bake(Track& track, int index, int interval, bool isRoundScale, bool isRoundRotation)
  {
    if (index < 0 || index >= (int)track.frames.size()) return;
    auto original = track.frames[index];
    if (original.duration <= FRAME_DURATION_MIN)
    {
      track.frames[index].interpolation = Interpolation::NONE;
      return;
    }

    auto next = index + 1 < (int)track.frames.size() ? track.frames[index + 1] : original;
    auto baked = frame_bake_split(original, next, interval, isRoundScale, isRoundRotation);
    track.frames.erase(track.frames.begin() + index);
    track.frames.insert(track.frames.begin() + index, baked.begin(), baked.end());
  }

  void frames_generate_from_grid(Track& track, glm::ivec2 startPosition, glm::ivec2 size, glm::vec2 pivot, int columns,
                                 int count, int duration)
  {
    for (int i = 0; i < count; ++i)
    {
      auto& frame = track.frames.emplace_back();
      frame.duration = duration;
      frame.pivot = pivot;
      frame.size = size;
      frame.crop = startPosition + glm::ivec2(size.x * (i % columns), size.y * (i / columns));
    }
  }

  void frames_sort_by_at_frame(Track& track)
  {
    std::stable_sort(track.frames.begin(), track.frames.end(),
                     [](const Frame& a, const Frame& b) { return a.atFrame < b.atFrame; });
  }

  void frames_change(Track& track, FrameChange change, ItemType itemType, ChangeType changeType,
                     const std::set<int>& selection)
  {
    auto apply = [&](auto& target, const auto& optionalValue)
    {
      if (!optionalValue) return;
      auto value = *optionalValue;
      if (changeType == ChangeType::ADJUST) target = value;
      if (changeType == ChangeType::ADD) target += value;
      if (changeType == ChangeType::SUBTRACT) target -= value;
      if (changeType == ChangeType::MULTIPLY) target *= value;
      if (changeType == ChangeType::DIVIDE && value != decltype(value){}) target /= value;
    };

    for (auto index : selection)
    {
      if (index < 0 || index >= (int)track.frames.size()) continue;
      auto& frame = track.frames[index];
      if (change.isVisible) frame.isVisible = *change.isVisible;
      if (change.interpolation) frame.interpolation = *change.interpolation;
      if (change.isFlipX) frame.scale.x = -frame.scale.x;
      if (change.isFlipY) frame.scale.y = -frame.scale.y;

      apply(frame.duration, change.duration);
      if (change.duration) frame.duration = std::max(FRAME_DURATION_MIN, frame.duration);
      if (itemType == ItemType::LAYER && change.regionId) frame.regionId = *change.regionId;
      if (itemType == ItemType::LAYER && change.shaderId) frame.shaderId = *change.shaderId;
#define X(name, member, isLayerOnly, isColor, isEnabled, value)                                                        \
  if (!isLayerOnly || itemType == ItemType::LAYER) apply(frame.member, change.name);
      FRAME_CHANGE_SCALARS
#undef X
    }
  }

  // Bounds of all visible layer frames over the animation's length, or -1 when nothing is drawn.
  glm::vec4 animation_rect(const Model& model, const Animation& animation, bool isRootTransform)
  {
    constexpr glm::ivec2 CORNERS[4] = {{0, 0}, {1, 0}, {1, 1}, {0, 1}};
    glm::vec2 min{std::numeric_limits<float>::infinity()};
    glm::vec2 max{-std::numeric_limits<float>::infinity()};
    bool isAny{};

    for (float time = 0.0f; time < (float)animation.frameNum; time += 1.0f)
      for (const auto& draw : animation_draws_get(model, animation, {.time = time, .isRootTransform = isRootTransform}))
      {
        if (draw.type != DrawType::LAYER || draw.frame.size == glm::vec2()) continue;
        auto transform = draw.parent * draw_quad_model_get(draw);
        for (auto& corner : CORNERS)
        {
          auto world = glm::vec2(transform * glm::vec4(corner, 0.0f, 1.0f));
          min = glm::min(min, world);
          max = glm::max(max, world);
          isAny = true;
        }
      }

    if (!isAny) return glm::vec4(-1.0f);
    return {min.x, min.y, max.x - min.x, max.y - min.y};
  }
}
