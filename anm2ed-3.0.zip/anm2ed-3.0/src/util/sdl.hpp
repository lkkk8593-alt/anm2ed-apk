#pragma once

#include <filesystem>

namespace anm2ed::util::sdl
{
  std::filesystem::path preferences_directory_get();
#ifdef __ANDROID__
  void android_working_directory_set();
#endif
}
