#include "sdl.hpp"

#include <SDL3/SDL_filesystem.h>
#include <SDL3/SDL_stdinc.h>

#include "path.hpp"

namespace anm2ed::util::sdl
{
  std::filesystem::path preferences_directory_get()
  {
    auto sdlPath = SDL_GetPrefPath(nullptr, "anm2ed");
    if (!sdlPath) return {};
    auto filePath = path::from_utf8(sdlPath);
    SDL_free(sdlPath);
    return filePath;
  }
}

#ifdef __ANDROID__
  #include <SDL3/SDL_system.h>

namespace anm2ed::util::sdl
{
  // Shared storage needs "All files access" (requested by the activity); the app's own folder is the fallback.
  void android_working_directory_set()
  {
    auto sharedDirectory = std::filesystem::path("/storage/emulated/0/Documents/Anm2Ed");
    std::error_code error{};
    std::filesystem::create_directories(sharedDirectory, error);
    if (!error && std::filesystem::is_directory(sharedDirectory))
    {
      std::filesystem::current_path(sharedDirectory, error);
      if (!error) return;
    }

    if (auto externalPath = SDL_GetAndroidExternalStoragePath()) std::filesystem::current_path(externalPath, error);
  }
}
#endif
