#pragma once

#include <cstddef>
#include <iterator>
#include <tuple>
#include <utility>

// Stand-in for std::views::enumerate (missing from libc++, which Android uses).
namespace anm2ed::util
{
  template <typename Range> auto enumerate(Range&& range)
  {
    using Iterator = decltype(std::begin(range));
    struct View
    {
      Iterator first, last;
      struct Cursor
      {
        Iterator it;
        std::ptrdiff_t index;
        auto operator*() const { return std::tuple<std::ptrdiff_t, decltype(*it)>(index, *it); }
        Cursor& operator++()
        {
          ++it, ++index;
          return *this;
        }
        bool operator!=(const Cursor& other) const { return it != other.it; }
      };
      Cursor begin() const { return {first, 0}; }
      Cursor end() const { return {last, 0}; }
    };
    return View{std::begin(range), std::end(range)};
  }
}
