#include "render_animation.hpp"

#include <algorithm>
#include <ranges>
#include <set>
#include <string>

#include "log.hpp"
#include "path.hpp"
#include "process.hpp"
#include "render.hpp"
#include "toast.hpp"
#include "util/imgui/input.hpp"
#include "util/imgui/layout.hpp"
#include "util/imgui/shortcut.hpp"

using namespace anm2ed::resource;
using namespace anm2ed::util;

namespace anm2ed::imgui::wizard
{
  void RenderAnimation::range_to_animation_set(Manager& manager, Document& document)
  {
    if (auto animation = document.model.animation_get(document.reference_get().animationIndex))
    {
      manager.recordingStart = 0;
      manager.recordingEnd = animation->frameNum - 1;
    }
  }

  void RenderAnimation::range_to_frames_set(Manager& manager, Document& document)
  {
    auto frameReferences = document.frame_references_get(Document::FrameReferenceFallback::NONE);
    auto reference = document.reference_get();
    std::erase_if(frameReferences,
                  [&](const Reference& frameReference)
                  {
                    return frameReference.animationIndex != reference.animationIndex ||
                           frameReference.itemType != reference.itemType || frameReference.itemID != reference.itemID ||
                           frameReference.groupType != reference.groupType ||
                           frameReference.groupId != reference.groupId;
                  });
    if (!frameReferences.empty())
    {
      if (auto item = document.model.track_get(reference))
      {
        int duration{};
        int frameIndex{};
        for (auto& frame : item->frames)
        {
          if (frameIndex == frameReferences.begin()->frameIndex) manager.recordingStart = duration;
          if (frameIndex == frameReferences.rbegin()->frameIndex) manager.recordingEnd = duration + frame.duration - 1;

          duration += frame.duration;
          ++frameIndex;
        }
      }
    }
  }

  void RenderAnimation::reset(Manager& manager, Document& document, Settings& settings)
  {
    if (!manager.isRecordingRange) range_to_animation_set(manager, document);
    settings.renderPath.replace_extension(render::EXTENSIONS[settings.renderType]);
  }

  void RenderAnimation::update(Manager& manager, Document& document, Resources& resources, Settings& settings,
                               Dialog& dialog)
  {
    isEnd = false;

    auto animation = document.model.animation_get(document.reference_get().animationIndex);
    if (!animation) return;

    auto& ffmpegPath = settings.renderFFmpegPath;
    auto& path = settings.renderPath;
    auto& format = settings.renderFormat;
    auto& scale = settings.renderScale;
    auto& renderFpsMode = settings.renderFpsMode;
    auto& isUseAnimationBounds = settings.renderIsUseAnimationBounds;
    auto& isUseIsolatedAnimation = settings.renderIsUseIsolatedAnimation;
    auto& type = settings.renderType;
    auto& start = manager.recordingStart;
    auto& end = manager.recordingEnd;
    auto& rows = settings.renderRows;
    auto& columns = settings.renderColumns;
    auto& isRange = manager.isRecordingRange;
    auto reference = document.reference_get();
    auto& frameNum = animation->frameNum;
    auto animationFrameNum = std::max(frameNum, 1);
    auto frameMax = animationFrameNum - 1;
    start = std::clamp(start, 0, frameMax);
    end = std::clamp(end, start, frameMax);
    auto animationFps = std::max(document.model.info.fps, 1);
    if (renderFpsMode < render::FPS_ANIMATION || renderFpsMode >= render::FPS_COUNT)
      renderFpsMode = render::FPS_ANIMATION;
    auto renderFps = render::fps_get(renderFpsMode, animationFps, settings.playbackTickRate);
    auto render_frame_count_get = [&]()
    {
      if (isRange) return render::frame_count_get(start, end, animationFps, renderFps);
      return render::frame_count_get(0, frameMax, animationFps, renderFps);
    };
    auto renderFrameNum = render_frame_count_get();

    auto widgetSize = widget_size_with_row_get(2);

    Dialog::Type dialogType{Dialog::NONE};
    switch (type)
    {
      case render::PNGS:
        dialogType = Dialog::PNG_DIRECTORY_SET;
        break;
      case render::SPRITESHEET:
        dialogType = Dialog::PNG_PATH_SET;
        break;
      case render::GIF:
        dialogType = Dialog::GIF_PATH_SET;
        break;
      case render::WEBM:
        dialogType = Dialog::WEBM_PATH_SET;
        break;
      case render::OGV:
        dialogType = Dialog::OGV_PATH_SET;
        break;
      case render::MP4:
        dialogType = Dialog::MP4_PATH_SET;
        break;
      default:
        dialogType = Dialog::NONE;
        break;
    }

    if (ImGui::ImageButton("##FFmpeg Path Set", resources.icon_id_get(icon::FOLDER), icon_size_get()))
      dialog.file_open(Dialog::FFMPEG_PATH_SET);
    ImGui::SameLine();
    input_text_path(localize.get(LABEL_FFMPEG_PATH), &ffmpegPath);
    ImGui::SetItemTooltip("%s", localize.get(TOOLTIP_FFMPEG_PATH));

    if (dialog.is_selected(Dialog::FFMPEG_PATH_SET))
    {
      ffmpegPath = dialog.path;
      dialog.reset();
    }

    if (ImGui::ImageButton("##Path Set", resources.icon_id_get(icon::FOLDER), icon_size_get()))
    {
      if (dialogType == Dialog::PNG_DIRECTORY_SET)
        dialog.folder_open(dialogType);
      else
        dialog.file_save(dialogType);
    }

    ImGui::SameLine();
    auto pathLabel = type == render::PNGS ? LABEL_OUTPUT_DIRECTORY : LABEL_OUTPUT_PATH;
    input_text_path(localize.get(pathLabel), &path);
    ImGui::SetItemTooltip("%s", localize.get(TOOLTIP_OUTPUT_PATH));

    if (dialog.is_selected(dialogType))
    {
      path = dialog.path;
      dialog.reset();
    }

    if (ImGui::Combo(localize.get(LABEL_TYPE), &type, render::STRINGS, render::COUNT))
      path.replace_extension(render::EXTENSIONS[type]);

    ImGui::SetItemTooltip("%s", localize.get(TOOLTIP_RENDER_TYPE));

    if (type == render::PNGS || type == render::SPRITESHEET) ImGui::Separator();

    if (type == render::PNGS)
    {
      input_text_path(localize.get(LABEL_FORMAT), &format);
      ImGui::SetItemTooltip("%s", localize.get(TOOLTIP_FORMAT));
    }
    else if (type == render::SPRITESHEET)
    {
      input_int_range(localize.get(LABEL_GENERATE_ROWS), rows, 1, renderFrameNum);
      ImGui::SetItemTooltip("%s", localize.get(TOOLTIP_ROWS));

      input_int_range(localize.get(LABEL_GENERATE_COLUMNS), columns, 1, renderFrameNum);
      ImGui::SetItemTooltip("%s", localize.get(TOOLTIP_COLUMNS));
    }

    ImGui::Separator();

    ImGui::Checkbox(localize.get(LABEL_CUSTOM_RANGE), &isRange);
    ImGui::SetItemTooltip("%s", localize.get(TOOLTIP_CUSTOM_RANGE));

    ImGui::SameLine();

    ImGui::BeginDisabled(document.frame_references_get(Document::FrameReferenceFallback::NONE).empty() ||
                         reference.itemType == TRIGGER);
    if (ImGui::Button(localize.get(LABEL_TO_SELECTED_FRAMES))) range_to_frames_set(manager, document);
    ImGui::SetItemTooltip("%s", localize.get(TOOLTIP_TO_SELECTED_FRAMES));
    ImGui::EndDisabled();

    ImGui::SameLine();

    if (ImGui::Button(localize.get(LABEL_TO_ANIMATION_RANGE))) range_to_animation_set(manager, document);
    ImGui::SetItemTooltip("%s", localize.get(TOOLTIP_TO_ANIMATION_RANGE));

    ImGui::BeginDisabled(!isRange);
    {
      input_int_range(localize.get(LABEL_START), start, 0, frameMax);
      ImGui::SetItemTooltip("%s", localize.get(TOOLTIP_START));
      input_int_range(localize.get(LABEL_END), end, start, frameMax);
      ImGui::SetItemTooltip("%s", localize.get(TOOLTIP_END));
    }
    ImGui::EndDisabled();
    renderFrameNum = render_frame_count_get();

    if (type == render::SPRITESHEET)
    {
      auto layout = render::spritesheet_layout_get(rows, columns, renderFrameNum);
      rows = layout.rows;
      columns = layout.columns;
    }

    ImGui::Separator();

    ImGui::Checkbox(localize.get(LABEL_USE_ANIMATION_BOUNDS), &isUseAnimationBounds);
    ImGui::SetItemTooltip("%s", localize.get(TOOLTIP_USE_ANIMATION_BOUNDS));

    ImGui::SameLine();

    ImGui::Checkbox(localize.get(LABEL_USE_ISOLATED_ANIMATION), &isUseIsolatedAnimation);
    ImGui::SetItemTooltip("%s", localize.get(TOOLTIP_USE_ISOLATED_ANIMATION));

    ImGui::BeginDisabled(!isUseAnimationBounds);
    {
      input_float_range(localize.get(BASIC_SCALE), scale, RENDER_SCALE_MIN, RENDER_SCALE_MAX, RENDER_SCALE_STEP,
                        RENDER_SCALE_STEP, "%.0f%%");
      ImGui::SetItemTooltip("%s", localize.get(TOOLTIP_SCALE_OUTPUT));
    }
    ImGui::EndDisabled();

    ImGui::Separator();

    const char* renderFpsOptions[] = {localize.get(LABEL_ANIMATION_FPS), localize.get(LABEL_PLAYBACK_RATE)};
    ImGui::Combo(localize.get(LABEL_RENDER_FPS), &renderFpsMode, renderFpsOptions, IM_ARRAYSIZE(renderFpsOptions));
    ImGui::SetItemTooltip("%s", localize.get(TOOLTIP_RENDER_FPS));

    renderFps = render::fps_get(renderFpsMode, animationFps, settings.playbackTickRate);
    renderFrameNum = render_frame_count_get();
    if (type == render::SPRITESHEET)
    {
      auto layout = render::spritesheet_layout_get(rows, columns, renderFrameNum);
      rows = layout.rows;
      columns = layout.columns;
    }

    ImGui::Separator();

    ImGui::Checkbox(localize.get(LABEL_SOUND), &settings.timelineIsSound);
    ImGui::SetItemTooltip("%s", localize.get(TOOLTIP_SOUND));

    ImGui::Separator();

    imgui::shortcut(manager.chords[SHORTCUT_CONFIRM]);
    if (ImGui::Button(localize.get(LABEL_RENDER), widgetSize))
    {
      path.replace_extension(render::EXTENSIONS[type]);

      auto render_is_valid = [&]()
      {
        auto ffmpeg_is_valid = [&]()
        {
          if (!path::is_executable(ffmpegPath)) return false;

          auto testCommand = std::string("\"") + path::to_utf8(ffmpegPath) + "\" -version";
          Process process(testCommand.c_str(), "r");
          auto result = process.output_get_and_close();

          if (!result.contains("ffmpeg version")) return false;

          return true;
        };

        auto ffmpeg_valid_check = [&]()
        {
          if (!ffmpeg_is_valid())
          {
            toast_log(Level::ERROR, TOAST_INVALID_FFMPEG);
            return false;
          }
          return true;
        };

        auto png_format_valid_check = [&]()
        {
          auto formatString = path::to_utf8(format);
          if (!formatString.contains("{}"))
          {
            toast_log(Level::ERROR, TOAST_PNG_FORMAT_INVALID);
            return false;
          }
          return true;
        };

        auto path_valid_check = [&]()
        {
          if (path.empty())
          {
            toast_log(Level::ERROR, TOAST_RENDER_PATH_EMPTY);
            return false;
          }
          return true;
        };

        auto png_directory_valid_check = [&]()
        {
          if (!path::ensure_directory(path))
          {
            toast_log(Level::ERROR, TOAST_PNG_DIRECTORY_INVALID);
            return false;
          }
          return true;
        };

        auto spritesheet_valid_check = [&]()
        {
          if (rows <= 0 && columns <= 0)
          {
            toast_log(Level::ERROR, TOAST_RENDER_PATH_EMPTY);
            return false;
          }
          return true;
        };

        if (!path_valid_check()) return false;

        switch (type)
        {
          case render::PNGS:
            if (!png_format_valid_check()) return false;
            if (!png_directory_valid_check()) return false;
            format.replace_extension(render::EXTENSIONS[render::SPRITESHEET]);
            break;
          case render::SPRITESHEET:
            if (!spritesheet_valid_check()) return false;
            break;
          case render::GIF:
          case render::WEBM:
          case render::OGV:
          case render::MP4:
            if (!ffmpeg_valid_check()) return false;
            break;
          default:
            return false;
            break;
        }

        return true;
      };

      if (render_is_valid())
      {
        manager.isRecordingStart = true;
        manager.progressPopup.open();
      }

      isEnd = true;
    }

    ImGui::SetItemTooltip("%s", localize.get(TOOLTIP_RENDER_BUTTON));

    ImGui::SameLine();

    imgui::shortcut(manager.chords[SHORTCUT_CANCEL]);
    if (ImGui::Button(localize.get(BASIC_CANCEL), widgetSize)) isEnd = true;
  }
}
