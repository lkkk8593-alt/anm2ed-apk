#include "shaders.hpp"

#include <filesystem>
#include <format>
#include <vector>

#include <imgui/imgui.h>

#include "path.hpp"
#include "strings.hpp"
#include "toast.hpp"
#include "util/imgui/input.hpp"
#include "util/imgui/layout.hpp"

using namespace anm2ed::resource;
using namespace anm2ed::util;

namespace anm2ed::imgui
{
  constexpr int SHADER_CARD_LINES = 2;

#define SHADER_UNIFORM_BINDING_COMBO_VALUES                                                                            \
  X(resource::shader::UNIFORM_BINDING_IGNORE)                                                                          \
  X(resource::shader::UNIFORM_BINDING_MANUAL)                                                                          \
  X(resource::shader::UNIFORM_BINDING_COLOR_OFFSET)                                                                    \
  X(resource::shader::UNIFORM_BINDING_FRAME_TINT)                                                                      \
  X(resource::shader::UNIFORM_BINDING_MAIN_TEXTURE)                                                                    \
  X(resource::shader::UNIFORM_BINDING_COMPONENTS)                                                                      \
  X(resource::shader::UNIFORM_BINDING_PLAYBACK_TIME)                                                                   \
  X(resource::shader::UNIFORM_BINDING_TEXTURE_SIZE)                                                                    \
  X(resource::shader::UNIFORM_BINDING_TRANSFORM)

  inline constexpr resource::shader::UniformBinding SHADER_UNIFORM_BINDING_COMBO_ORDER[] = {
#define X(binding) binding,
      SHADER_UNIFORM_BINDING_COMBO_VALUES
#undef X
  };
#undef SHADER_UNIFORM_BINDING_COMBO_VALUES

  std::filesystem::path shader_absolute_path_get(Document& document, const std::filesystem::path& shaderPath)
  {
    auto loadPath = path::backslash_handle(shaderPath);
    if (loadPath.empty() || loadPath.is_absolute()) return loadPath;
    return document.directory_get() / loadPath;
  }

  bool is_shader_reload_needed(Document& document, model::Shader* shader)
  {
    if (!shader || shader->fragment.empty()) return false;
    if (!document.shader_get(shader->id)) return true;
    if (!document.shaderVertexPaths.contains(shader->id) || !document.shaderFragmentPaths.contains(shader->id))
      return true;
    return document.shaderVertexPaths.at(shader->id) != shader->vertex ||
           document.shaderFragmentPaths.at(shader->id) != shader->fragment;
  }

  model::Shader* shader_element_get(Document& document, int id)
  {
    return model::item_get(document.model.content.shaders, id);
  }

  std::filesystem::path shader_asset_path_get(Document& document, const std::filesystem::path& path)
  {
    auto loadPath = path::backslash_handle(path);
    return path::backslash_replace(path::make_relative(loadPath, document.directory_get()));
  }

  void shader_path_edit(Document& document, int shaderId, std::filesystem::path model::Shader::* member,
                        const std::filesystem::path& value)
  {
    auto shader = shader_element_get(document, shaderId);
    if (shader)
    {
      shader->*member = path::backslash_replace(value);
      document.change();
    }
  }

  void shader_dialog_update(ShadersPanel& window, Manager& manager, Dialog& dialog, Dialog::Type type,
                            std::filesystem::path model::Shader::* member)
  {
    if (!dialog.is_selected(type)) return;

    auto dialogPath = dialog.path;
    auto shaderId = window.dialogShaderId;
    manager.command_push(
        {manager.selected, [dialogPath, shaderId, member](Manager&, Document& document)
         { shader_path_edit(document, shaderId, member, shader_asset_path_get(document, dialogPath)); }});
    window.dialogShaderId = -1;
    dialog.reset();
  }

  void shader_path_row_update(ShadersPanel& window, Document& document, Resources& resources, Dialog& dialog,
                              model::Shader* shader, std::filesystem::path model::Shader::* member,
                              Dialog::Type dialogType, StringType label)
  {
    auto shaderPath = shader ? shader->*member : std::filesystem::path{};
    auto isDefault = shaderPath.empty();
    auto displayPath = isDefault ? path::from_utf8(localize.get(BASIC_DEFAULT)) : shaderPath;

    if (ImGui::ImageButton(std::format("##{} Path Set", localize.get(label)).c_str(),
                           resources.icon_id_get(icon::FOLDER), icon_size_get()))
    {
      if (shader)
      {
        window.dialogShaderId = shader->id;
        dialog.file_open(dialogType);
      }
    }

    ImGui::SameLine();

    auto labelWidth = ImGui::CalcTextSize(localize.get(label)).x;
    auto inputWidth = ImGui::GetContentRegionAvail().x - labelWidth - ImGui::GetStyle().ItemSpacing.x;
    if (inputWidth < ImGui::GetFrameHeight()) inputWidth = ImGui::GetFrameHeight();
    ImGui::SetNextItemWidth(inputWidth);
    ImGui::BeginDisabled(isDefault);
    auto isEdited = input_text_path(std::format("##{} Path", localize.get(label)).c_str(), &displayPath);
    ImGui::EndDisabled();
    if (isEdited && shader) shader_path_edit(document, shader->id, member, displayPath);

    ImGui::SameLine();
    ImGui::TextUnformatted(localize.get(label));
  }

  void shader_uniform_config_save(Document& document, model::Shader& shaderElement,
                                  const resource::shader::Uniform& uniform)
  {
    resource::shader::uniform_config_save(shaderElement, uniform);
    document.change();
  }

  void shader_uniform_components_from_value_set(resource::shader::Uniform& uniform)
  {
    for (int i = 0; i < (int)uniform.components.size(); ++i)
      uniform.components[i].value = uniform.value[i];
  }

  void shader_uniform_value_from_components_set(resource::shader::Uniform& uniform)
  {
    for (int i = 0; i < (int)uniform.components.size(); ++i)
      uniform.value[i] = uniform.components[i].value;
  }

  bool shader_uniform_value_update(resource::shader::Uniform& uniform)
  {
    ImGui::SetNextItemWidth(-1.0f);
    switch (uniform.valueType)
    {
      case resource::shader::UNIFORM_VALUE_FLOAT:
        return ImGui::DragFloat("##Value", &uniform.value.x, 0.01f);
      case resource::shader::UNIFORM_VALUE_INT:
      case resource::shader::UNIFORM_VALUE_SAMPLER2D:
        return ImGui::InputInt("##Value", &uniform.intValue);
      case resource::shader::UNIFORM_VALUE_VEC2:
        return ImGui::DragFloat2("##Value", &uniform.value.x, 0.01f);
      case resource::shader::UNIFORM_VALUE_VEC3:
        return ImGui::DragFloat3("##Value", &uniform.value.x, 0.01f);
      case resource::shader::UNIFORM_VALUE_VEC4:
        return ImGui::DragFloat4("##Value", &uniform.value.x, 0.01f);
      default:
        ImGui::TextUnformatted(localize.get(BASIC_NONE));
        return false;
    }
  }

  bool shader_uniform_component_binding_update(resource::shader::Uniform::Component& component)
  {
    auto bindingLabel = resource::shader::uniform_binding_label_get(component.binding);
    ImGui::SetNextItemWidth(ImGui::GetFrameHeight() * 5.0f);
    if (!ImGui::BeginCombo("##Component Binding", bindingLabel.data())) return false;

    bool isChanged{};
    constexpr resource::shader::UniformBinding bindings[] = {resource::shader::UNIFORM_BINDING_MANUAL,
                                                             resource::shader::UNIFORM_BINDING_PLAYBACK_TIME};
    for (auto binding : bindings)
    {
      auto isSelected = component.binding == binding;
      auto label = resource::shader::uniform_binding_label_get(binding);
      if (ImGui::Selectable(label.data(), isSelected))
      {
        component.binding = binding;
        isChanged = true;
      }
      if (isSelected) ImGui::SetItemDefaultFocus();
    }
    ImGui::EndCombo();
    return isChanged;
  }

  bool shader_uniform_components_update(resource::shader::Uniform& uniform)
  {
    bool isChanged{};
    constexpr const char* labels[] = {"X", "Y", "Z", "W"};
    auto componentCount = resource::shader::UNIFORM_VALUE_TYPE_INFOS[uniform.valueType].componentCount;

    for (int index = 0; index < componentCount; ++index)
    {
      auto& component = uniform.components[index];
      ImGui::PushID(index);
      if (index > 0) ImGui::Spacing();
      ImGui::TextUnformatted(labels[index]);
      ImGui::SameLine();
      if (shader_uniform_component_binding_update(component)) isChanged = true;
      ImGui::SameLine();
      ImGui::BeginDisabled(component.binding != resource::shader::UNIFORM_BINDING_MANUAL);
      ImGui::SetNextItemWidth(-1.0f);
      if (ImGui::DragFloat("##Component Value", &component.value, 0.01f)) isChanged = true;
      ImGui::EndDisabled();
      ImGui::PopID();
    }

    if (isChanged) shader_uniform_value_from_components_set(uniform);
    return isChanged;
  }

  void shader_uniforms_update(Document& document, model::Shader* shaderElement, resource::Shader* runtime,
                              ImVec2 tableSize)
  {
    if (!shaderElement) return;

    auto flags = ImGuiTableFlags_BordersInnerV | ImGuiTableFlags_BordersOuterH | ImGuiTableFlags_RowBg |
                 ImGuiTableFlags_Resizable | ImGuiTableFlags_SizingStretchProp | ImGuiTableFlags_ScrollY;
    if (tableSize.x <= 0.0f) tableSize.x = ImGui::GetContentRegionAvail().x;
    if (tableSize.y <= 0.0f) tableSize.y = ImGui::GetContentRegionAvail().y;
    if (tableSize.y < ImGui::GetFrameHeight()) tableSize.y = ImGui::GetFrameHeight();
    if (!ImGui::BeginTable("##Shader Uniforms", 4, flags, tableSize)) return;

    ImGui::TableSetupColumn(localize.get(BASIC_NAME));
    ImGui::TableSetupColumn(localize.get(LABEL_TYPE));
    ImGui::TableSetupColumn(localize.get(LABEL_BINDING));
    ImGui::TableSetupColumn(localize.get(LABEL_VALUE_COLUMN));
    ImGui::TableSetupScrollFreeze(0, 1);
    ImGui::TableHeadersRow();

    if (runtime)
      for (auto& uniform : runtime->uniforms)
      {
        ImGui::PushID(uniform.name.c_str());
        ImGui::TableNextRow();

        ImGui::TableNextColumn();
        ImGui::TextUnformatted(uniform.name.c_str());

        ImGui::TableNextColumn();
        ImGui::TextUnformatted(resource::shader::uniform_value_type_label_get(uniform.valueType).data());

        ImGui::TableNextColumn();
        auto bindingLabel = resource::shader::uniform_binding_label_get(uniform.binding);
        ImGui::SetNextItemWidth(-1.0f);
        if (ImGui::BeginCombo("##Binding", bindingLabel.data()))
        {
          for (auto binding : SHADER_UNIFORM_BINDING_COMBO_ORDER)
          {
            if (!resource::shader::is_uniform_binding_valid(binding, uniform.valueType)) continue;
            auto isSelected = uniform.binding == binding;
            auto label = resource::shader::uniform_binding_label_get(binding);
            if (ImGui::Selectable(label.data(), isSelected))
            {
              uniform.binding = binding;
              if (uniform.binding == resource::shader::UNIFORM_BINDING_COMPONENTS)
                shader_uniform_components_from_value_set(uniform);
              shader_uniform_config_save(document, *shaderElement, uniform);
            }
            if (isSelected) ImGui::SetItemDefaultFocus();
          }
          ImGui::EndCombo();
        }

        ImGui::TableNextColumn();
        if (uniform.binding == resource::shader::UNIFORM_BINDING_COMPONENTS)
        {
          if (shader_uniform_components_update(uniform)) shader_uniform_config_save(document, *shaderElement, uniform);
        }
        else
        {
          ImGui::BeginDisabled(uniform.binding != resource::shader::UNIFORM_BINDING_MANUAL);
          if (shader_uniform_value_update(uniform))
          {
            shader_uniform_components_from_value_set(uniform);
            shader_uniform_config_save(document, *shaderElement, uniform);
          }
          ImGui::EndDisabled();
        }

        ImGui::PopID();
      }

    ImGui::EndTable();
  }

  auto& shaders_get(model::Model& model) { return model.content.shaders; }

  void shaders_update(Panel& panel, ShadersPanel& shaders)
  {
    auto& [manager, settings, resources, dialog, clipboard, document, state] = panel;
    auto& items = document.model.content.shaders;
    auto& status = shaders.status;
    auto& propertiesPopup = shaders.propertiesPopup;
    auto& popupShaderId = shaders.popupShaderId;
    shader_dialog_update(shaders, manager, dialog, Dialog::SHADER_VERTEX_PATH_SET, &model::Shader::vertex);
    shader_dialog_update(shaders, manager, dialog, Dialog::SHADER_FRAGMENT_PATH_SET, &model::Shader::fragment);

    if (ImGui::Begin(localize.get(LABEL_SHADERS_WINDOW), &settings.windowIsShaders))
    {
      auto selection = document.selected_ids_get(SelectionKind::SHADERS);
      auto properties_open = [&](int id)
      {
        document.selected_ids_set(SelectionKind::SHADERS, {id});
        popupShaderId = id;
        propertiesPopup.open();
      };

      Actions actions{};
      actions.add(
          ACTION_ADD, {},
          [&]()
          {
            command_push(panel,
                         [&state](Document& document)
                         {
                           int id{};
                           document.edit_apply(EDIT_ADD_SHADER,
                                               [&](model::Model& model)
                                               {
                                                 auto& shaders = model.content.shaders;
                                                 id = model::item_next_id_get(shaders);
                                                 shaders.push_back({.id = id, .name = localize.get(TEXT_NEW_SHADER)});
                                               });
                           document.selected_ids_set(SelectionKind::SHADERS, {id});
                           document.focused_id_set(SelectionKind::SHADERS, id);
                           state.newId = id;
                         });
          },
          TOOLTIP_ADD_SHADER);
      actions.add(
          ACTION_REMOVE_UNUSED, {},
          [&]() { items_unused_remove(panel, ElementType::SHADER, EDIT_REMOVE_UNUSED_SHADERS, shaders_get); },
          TOOLTIP_REMOVE_UNUSED_SHADERS);
      actions.add(
          ACTION_RELOAD, [selection]() { return !selection.empty(); },
          [&]()
          {
            status.clear();
            for (auto id : selection)
              if (auto shader = shader_element_get(document, id))
              {
                document.shader_reload(id, &status);
                toasts.push(std::vformat(localize.get(TOAST_RELOAD_SHADER), std::make_format_args(id, shader->name)));
              }
          },
          TOOLTIP_RELOAD_SHADERS);

      auto image_get = [&](int id)
      {
        auto isValid = document.shader_get(id) != nullptr;
        auto& image = resources.icons[isValid ? icon::SHADER : icon::NONE];
        return CardImage{.texture = &image, .size = glm::vec2(image.size), .isValid = isValid};
      };
      ListRows rows{.label_get =
                        [&](int id)
                    {
                      auto name = shader_element_get(document, id)->name;
                      return std::vformat(localize.get(FORMAT_SHADER), std::make_format_args(id, name));
                    },
                    .tooltip_draw =
                        [&](int id)
                    {
                      auto& shader = *shader_element_get(document, id);
                      tooltip_name_draw(resources, shader.name);
                      ImGui::Text("%s: %d", localize.get(BASIC_ID), id);
                      ImGui::Text("%s: %s", localize.get(LABEL_VERTEX), path::to_utf8(shader.vertex).c_str());
                      ImGui::Text("%s: %s", localize.get(LABEL_FRAGMENT), path::to_utf8(shader.fragment).c_str());
                      if (image_get(id).isValid) return;
                      ImGui::Spacing();
                      ImGui::TextWrapped("%s", localize.get(TOOLTIP_SHADER_INVALID));
                    },
                    .image_get = image_get,
                    .activate = properties_open,
                    .cardLines = SHADER_CARD_LINES};
      list_panel_draw(
          panel, actions, {{ACTION_ADD, ACTION_REMOVE_UNUSED, ACTION_RELOAD}},
          [&]() { content_list_draw(panel, SelectionKind::SHADERS, item_ids_get(items), rows); }, true);

      propertiesPopup.trigger();
      if (ImGui::BeginPopupModal(propertiesPopup.label(), &propertiesPopup.isOpen, ImGuiWindowFlags_NoResize))
      {
        auto shader = shader_element_get(document, popupShaderId);
        if (!shader) propertiesPopup.close();
        if (!shader)
        {
          ImGui::EndPopup();
          propertiesPopup.end();
          ImGui::End();
          return;
        }

        auto popupSize = size_without_footer_get();
        if (popupSize.y < ImGui::GetFrameHeight()) popupSize.y = ImGui::GetFrameHeight();
        if (ImGui::BeginChild("##Shader Properties Child", popupSize))
        {
          if (propertiesPopup.isJustOpened) ImGui::SetKeyboardFocusHere();
          if (input_text_string(localize.get(BASIC_NAME), &shader->name)) document.change();

          ImGui::SeparatorText(localize.get(LABEL_FILES));

          shader_path_row_update(shaders, document, resources, dialog, shader, &model::Shader::vertex,
                                 Dialog::SHADER_VERTEX_PATH_SET, LABEL_VERTEX);
          shader_path_row_update(shaders, document, resources, dialog, shader, &model::Shader::fragment,
                                 Dialog::SHADER_FRAGMENT_PATH_SET, LABEL_FRAGMENT);

          if (is_shader_reload_needed(document, shader))
            ImGui::TextWrapped("%s", localize.get(LABEL_SHADER_RELOAD_NEEDED));

          ImGui::SeparatorText(localize.get(LABEL_UNIFORMS));

          auto runtime = document.shader_get(shader->id);
          auto tableSize = ImVec2(ImGui::GetContentRegionAvail().x, ImGui::GetTextLineHeightWithSpacing() * 8.0f);
          auto outputReserve = ImGui::GetTextLineHeightWithSpacing() * 6.0f;
          auto availableHeight = ImGui::GetContentRegionAvail().y;
          if (availableHeight - outputReserve < tableSize.y) tableSize.y = availableHeight - outputReserve;
          if (tableSize.y < ImGui::GetFrameHeight()) tableSize.y = ImGui::GetFrameHeight();
          shader_uniforms_update(document, shader, runtime, tableSize);

          ImGui::SeparatorText(localize.get(LABEL_OUTPUT));

          auto consoleSize = ImGui::GetContentRegionAvail();
          if (consoleSize.y < ImGui::GetFrameHeight()) consoleSize.y = ImGui::GetFrameHeight();
          if (ImGui::BeginChild("##Shaders Output", consoleSize, ImGuiChildFlags_Borders))
            ImGui::TextWrapped("%s", status.c_str());
          ImGui::EndChild();
        }
        ImGui::EndChild();

        auto popupWidgetSize = widget_size_with_row_get(2);
        if (ImGui::Button(localize.get(BASIC_CONFIRM), popupWidgetSize))
        {
          status.clear();
          document.shader_reload(shader->id, &status);
          propertiesPopup.close();
        }
        ImGui::SetItemTooltip("%s", localize.get(TOOLTIP_RELOAD_SHADERS));
        ImGui::SameLine();
        if (ImGui::Button(localize.get(BASIC_CANCEL), popupWidgetSize)) propertiesPopup.close();

        ImGui::EndPopup();
      }
      propertiesPopup.end();
    }
    ImGui::End();
  }
}
