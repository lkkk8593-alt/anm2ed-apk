#pragma once

#include <filesystem>
#include <vector>

#include <SDL3/SDL.h>

namespace anm2ed
{
  class Dialog
  {
  public:
#if defined(_WIN32)
  #define EXECUTABLE_FILTER {"Executable", "exe"}
#else
  #define EXECUTABLE_FILTER {"Executable", "*"}
#endif

#define FILTER_LIST                                                                                                    \
  X(NO_FILTER, {})                                                                                                     \
  X(ANM2, {"Anm2 file", "anm2;xml"})                                                                                   \
  X(PNG, {"PNG image", "png;PNG"})                                                                                     \
  X(SHADER, {"Shader file", "fs;vs;FS;VS"})                                                                            \
  X(SOUND, {"WAV file;OGG file", "wav;ogg"})                                                                           \
  X(GIF, {"GIF image", "gif"})                                                                                         \
  X(WEBM, {"WebM video", "webm"})                                                                                      \
  X(OGV, {"OGV video", "ogv"})                                                                                         \
  X(MP4, {"MP4 video", "MP4"})                                                                                         \
  X(EXECUTABLE, EXECUTABLE_FILTER)

    enum Filter
    {
#define X(symbol, ...) symbol,
      FILTER_LIST
#undef X
    };

    static constexpr SDL_DialogFileFilter FILTERS[][1] = {
#define X(symbol, ...) {__VA_ARGS__},
        FILTER_LIST
#undef X
    };

#undef FILTER_LIST

#define DIALOG_LIST                                                                                                    \
  X(NONE, NO_FILTER)                                                                                                   \
  X(ANM2_CREATE, ANM2)                                                                                                 \
  X(ANM2_OPEN, ANM2)                                                                                                   \
  X(ANM2_SAVE, ANM2)                                                                                                   \
  X(SOUND_OPEN, SOUND)                                                                                                 \
  X(SOUND_REPLACE, SOUND)                                                                                              \
  X(SPRITESHEET_OPEN, PNG)                                                                                             \
  X(SPRITESHEET_REPLACE, PNG)                                                                                          \
  X(SPRITESHEET_PATH_SET, PNG)                                                                                         \
  X(SHADER_FRAGMENT_PATH_SET, SHADER)                                                                                   \
  X(SHADER_VERTEX_PATH_SET, SHADER)                                                                                     \
  X(FFMPEG_PATH_SET, EXECUTABLE)                                                                                       \
  X(PNG_DIRECTORY_SET, NO_FILTER)                                                                                      \
  X(PNG_PATH_SET, PNG)                                                                                                 \
  X(REGION_EXPORT_PATH_SET, PNG)                                                                                       \
  X(GIF_PATH_SET, GIF)                                                                                                 \
  X(WEBM_PATH_SET, WEBM)                                                                                               \
  X(OGV_PATH_SET, OGV)                                                                                                 \
  X(MP4_PATH_SET, MP4)

    enum Type
    {
#define X(symbol, filter) symbol,
      DIALOG_LIST
#undef X
    };

    static constexpr Filter TYPE_FILTERS[] = {
#define X(symbol, filter) filter,
        DIALOG_LIST
#undef X
    };

#undef DIALOG_LIST

    SDL_Window* window{};
    std::filesystem::path path{};
    std::vector<std::filesystem::path> paths{};
    Type type{NONE};
    int selectedFilter{-1};

    Dialog() = default;
    Dialog(SDL_Window*);
    void file_open(Type type, bool isMany = false);
    void file_save(Type type, const std::filesystem::path& defaultPath = {});
    void folder_open(Type type);
    bool is_selected(Type type) const;
    void reset();
    void file_explorer_open(const std::filesystem::path&);
  };
}
