#include "dialog.hpp"

#ifdef _WIN32
  #include <windows.h>
#elif __unix__ && !defined(__ANDROID__)
#else
  #include <SDL3/SDL_system.h>
  #include <cctype>
  #include <string>

  #include "log.hpp"
  #include "strings.hpp"
  #include "toast.hpp"
#endif

#include <cstdlib>
#include <cstring>
#include <format>

#include "path.hpp"

using namespace anm2ed::util;

namespace anm2ed
{
#ifdef __ANDROID__
  // Android's picker returns content:// URIs. Shared-storage URIs map back to real paths (needs "All files access");
  // anything else (Downloads, cloud providers) is copied into the app's cache so the rest of the app sees a file.
  static std::string uri_decode(const std::string& text)
  {
    std::string out{};
    for (size_t i = 0; i < text.size(); ++i)
    {
      if (text[i] == '%' && i + 2 < text.size() && std::isxdigit((unsigned char)text[i + 1]) &&
          std::isxdigit((unsigned char)text[i + 2]))
      {
        out += (char)std::stoi(text.substr(i + 1, 2), nullptr, 16);
        i += 2;
      }
      else
        out += text[i];
    }
    return out;
  }

  static std::string uri_path_get(const std::string& uri)
  {
    constexpr std::string_view STORAGE_PREFIX = "content://com.android.externalstorage.documents/";
    if (!uri.starts_with("content://")) return uri;

    if (uri.starts_with(STORAGE_PREFIX))
    {
      auto document = uri_decode(uri.substr(uri.rfind('/') + 1));
      auto colon = document.find(':');
      if (colon != std::string::npos)
      {
        auto volume = document.substr(0, colon);
        auto root = volume == "primary" ? std::string("/storage/emulated/0") : "/storage/" + volume;
        return root + "/" + document.substr(colon + 1);
      }
    }

    auto name = uri_decode(uri.substr(uri.rfind('/') + 1));
    if (auto slash = name.rfind('/'); slash != std::string::npos) name = name.substr(slash + 1);
    if (name.empty()) name = "imported";
    auto cache = SDL_GetAndroidCachePath();
    auto directory = std::filesystem::path(cache ? cache : "/data/local/tmp") / "imports";
    std::filesystem::create_directories(directory);
    auto destination = directory / name;
    size_t size{};
    if (auto data = SDL_LoadFile(uri.c_str(), &size))
    {
      if (auto file = SDL_IOFromFile(destination.c_str(), "wb"))
      {
        SDL_WriteIO(file, data, size);
        SDL_CloseIO(file);
      }
      SDL_free(data);
    }
    return destination.string();
  }
#endif

  static void callback(void* userData, const char* const* filelist, int filter)
  {
    auto self = (Dialog*)(userData);

    if (filelist && filelist[0] && strlen(filelist[0]) > 0)
    {
      self->paths.clear();
      for (int i = 0; filelist[i] && strlen(filelist[i]) > 0; ++i)
#ifdef __ANDROID__
        self->paths.push_back(path::from_utf8(uri_path_get(filelist[i])));
#else
        self->paths.push_back(path::from_utf8(filelist[i]));
#endif
      self->path = self->paths.empty() ? std::filesystem::path{} : self->paths.front();
      self->selectedFilter = filter;
    }
    else
    {
      self->selectedFilter = -1;
      self->path.clear();
      self->paths.clear();
    }
  }

  Dialog::Dialog(SDL_Window* window)
  {
    *this = Dialog();
    this->window = window;
  }

  void Dialog::file_open(Type type, bool isMany)
  {
    if (type == Dialog::NONE) return;
    path.clear();
    paths.clear();
    SDL_ShowOpenFileDialog(callback, this, window, FILTERS[TYPE_FILTERS[type]], std::size(FILTERS[TYPE_FILTERS[type]]),
                           nullptr, isMany);
    this->type = type;
  }

  void Dialog::file_save(Type type, const std::filesystem::path& defaultPath)
  {
    if (type == Dialog::NONE) return;
    path.clear();
    paths.clear();
    auto defaultPathString = path::to_utf8(defaultPath);
    auto defaultPathCStr = defaultPathString.empty() ? nullptr : defaultPathString.c_str();
    SDL_ShowSaveFileDialog(callback, this, window, FILTERS[TYPE_FILTERS[type]], std::size(FILTERS[TYPE_FILTERS[type]]),
                           defaultPathCStr);
    this->type = type;
  }

  void Dialog::folder_open(Type type)
  {
    if (type == Dialog::NONE) return;
    path.clear();
    paths.clear();
    SDL_ShowOpenFolderDialog(callback, this, window, nullptr, false);
    this->type = type;
  }

  void Dialog::file_explorer_open(const std::filesystem::path& path)
  {
    if (path.empty()) return;
#ifdef _WIN32
    ShellExecuteW(nullptr, L"open", path.native().c_str(), nullptr, nullptr, SW_SHOWNORMAL);
#elif defined(__ANDROID__)
    toast_log(Level::WARNING, TOAST_NOT_SUPPORTED);
#elif __unix__
    auto pathUtf8 = path::to_utf8(path);
    system(std::format("xdg-open \"{}\" &", pathUtf8).c_str());
#else
    toast_log(Level::WARNING, TOAST_NOT_SUPPORTED);
#endif
  }

  void Dialog::reset() { *this = Dialog(this->window); }

  bool Dialog::is_selected(Type type) const { return this->type == type && !paths.empty(); }

};
