# Anm2Ed para Android

1. `git submodule update --init --recursive` (SDL, SDL_mixer con sus dependencias, imgui rama docking, glm, tinyxml2, lunasvg).
2. Abrir la carpeta `android/` en Android Studio (necesita SDK 36, NDK 28.2.13676358 y CMake 3.27+).
3. Run en un dispositivo arm64 (o `./gradlew assembleDebug`).

- Al abrir la app pide "Acceso a todos los archivos": los .anm2 y sus spritesheets se leen/escriben como archivos normales.
  Carpeta por defecto: `Documents/Anm2Ed`.
- Pulsación larga = clic derecho (menús contextuales).
- Render a GIF/video requiere ffmpeg, que no existe en Android; PNG/spritesheet no.
- Sin ventanas desacopladas ni instancia única en Android.
