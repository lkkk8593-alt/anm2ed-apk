package app.anm2ed;

import android.Manifest;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;

import org.libsdl.app.SDLActivity;

public class Anm2EdActivity extends SDLActivity {
    private boolean isStoragePermissionAsked = false;

    // SDL is linked statically into libmain.so, so there is no separate libSDL3.so to load.
    @Override
    protected String[] getLibraries() {
        return new String[] {"main"};
    }

    @Override
    protected void onResume() {
        super.onResume();
        storagePermissionRequest();
    }

    // Documents and their spritesheets are plain files, so the app needs "All files access" (asked once per launch).
    private void storagePermissionRequest() {
        if (isStoragePermissionAsked) return;
        isStoragePermissionAsked = true;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) return;
            Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } else {
            requestPermissions(new String[] {
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE}, 0);
        }
    }
}
