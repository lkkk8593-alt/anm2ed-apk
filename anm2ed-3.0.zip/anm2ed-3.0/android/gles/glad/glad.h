#pragma once

// Android build: stands in for the desktop glad loader. The app links OpenGL ES 3.0 directly.
#include <GLES3/gl3.h>

#ifndef GL_CLAMP_TO_BORDER
  #define GL_CLAMP_TO_BORDER GL_CLAMP_TO_EDGE // border clamping is ES 3.2 / extension only
#endif

using GLADloadproc = void* (*)(const char*);
inline int gladLoadGLLoader(GLADloadproc) { return 1; }
